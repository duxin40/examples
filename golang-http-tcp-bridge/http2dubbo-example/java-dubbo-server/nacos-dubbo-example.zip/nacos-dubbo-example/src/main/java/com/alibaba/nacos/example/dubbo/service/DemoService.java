package com.alibaba.nacos.example.dubbo.service;

public interface DemoService {
    String sayName(String name);
}
