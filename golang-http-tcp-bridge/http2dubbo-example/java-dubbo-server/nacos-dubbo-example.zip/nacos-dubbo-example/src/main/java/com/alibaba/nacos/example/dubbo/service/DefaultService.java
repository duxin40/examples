package com.alibaba.nacos.example.dubbo.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.alibaba.dubbo.rpc.RpcContext;
import org.apache.http.conn.ConnectionKeepAliveStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.beans.factory.annotation.Value;

/**
 * Default {@link DemoService}
 *  https://nacos.io/zh-cn/docs/use-nacos-with-dubbo.html
 * @since 2.6.5
 */
@Service(version = "${demo.service.version}")
public class DefaultService implements DemoService {

    @Value("${demo.service.name}")
    private String serviceName;

    public String sayName(String name) {
        RpcContext rpcContext = RpcContext.getContext();
        rpcContext.getAttachment("");
        StringBuilder bigBody = new StringBuilder();
//        for (int i = 0; i <= 983470; i++) {
//            bigBody.append("a");
//        }
        return bigBody.toString() + String.format("Hello, %s !\n", name);
//        return String.format(bigBody + "Service [name :%s , port : %d] %s(\"%s\") : Hello,%s",
//                serviceName,
//                rpcContext.getLocalPort(),
//                rpcContext.getMethodName(),
//                name,
//                name);
    }
}